package com.mukesh.ip40.activities;

public class Branchid {
    public static String branch;
    public static String sem;
    public static Boolean cat;
}
