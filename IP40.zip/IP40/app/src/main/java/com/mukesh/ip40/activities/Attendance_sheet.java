package com.mukesh.ip40.activities;


public class Attendance_sheet {
    String p1,p2,p3,p4,p5,p6,p7,p8;

    public Attendance_sheet(String p1, String p2, String p3, String p4, String p5, String p6, String p7, String p8) {
        this.p1=p1;
        this.p2=p2;
        this.p3=p3;
        this.p4=p4;
        this.p5=p5;
        this.p6=p6;
        this.p7=p7;
        this.p8=p8;

    }

    public String getP1() {
        return p1;
    }
    public String getP2() {
        return p2;
    }
    public String getP3() {
        return p3;
    }
    public String getP4() {
        return p4;
    }
    public String getP5() { return p5; }
    public String getP6() {
        return p6;
    }
    public String getP7() {
        return p7;
    }
    public String getP8() {
        return p8;
    }
}
